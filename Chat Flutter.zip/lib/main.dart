import 'package:flutter/material.dart';
import 'widgets/chat_widget.dart';
import 'widgets/bar_widget.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Oculta la etiqueta de depuración en la esquina superior derecha

      title: 'Chat', // Título de la aplicación
      
      home: Scaffold(
        body: Column(
          children: [
            Expanded(child: Chat()), // Widget Chat que ocupa todo el espacio disponible
            Bar(), // Widget Bar que muestra la barra de entrada de texto
          ],
        ),
      ),
      
      theme: ThemeData(
        colorSchemeSeed: Color.fromARGB(255, 20, 14, 28), // Color principal de la aplicación
        useMaterial3: true, // Habilita el nuevo diseño de Material
      ),
      
      darkTheme: ThemeData(
        colorSchemeSeed: Color.fromARGB(255, 20, 14, 28), // Color principal de la aplicación en el tema oscuro
        useMaterial3: true, // Habilita el nuevo diseño de Material en el tema oscuro
        brightness: Brightness.dark, // Establece el brillo del tema en oscuro
      ),
      
      themeMode: ThemeMode.system, // Configura el modo de tema en función del tema del sistema
    );
  }
}


   //*   theme: ThemeData(
        //colorSchemeSeed: const Color.fromARGB(255, 1, 10, 17),
       // useMaterial3: true,
     // ),
      //darkTheme: ThemeData(
        //colorSchemeSeed: const Color.fromARGB(255, 1, 10, 17),
        //useMaterial3: true,
       // brightness: Brightness.dark,
     // ),
   //   themeMode: ThemeMode.system,