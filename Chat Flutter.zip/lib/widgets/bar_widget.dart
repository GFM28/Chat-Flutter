// widgets/bar_widget.dart
import 'package:flutter/material.dart';

class Bar extends StatelessWidget {
  const Bar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Controlador de texto para el campo de entrada de mensaje
    final TextEditingController _controller = TextEditingController();

    // Función para enviar el mensaje
    void _sendMessage() {
      // Agrega la lógica para enviar el mensaje aquí
      print('Mensaje enviado: ${_controller.text}');
      // Limpia el controlador de texto después de enviar el mensaje
      _controller.clear();
    }

    return Row(
      children: [
        // Campo de entrada de texto para el mensaje
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: TextField(
              controller: _controller,
              decoration: InputDecoration(
                fillColor: Color.fromARGB(255, 222, 159, 141).withOpacity(0.5), // Color de fondo del campo de entrada
                filled: true,
                hintText: 'Escribe tu mensaje aquí...', // Texto de sugerencia cuando el campo está vacío
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20), // Borde redondeado del campo de entrada
                  borderSide: BorderSide(color: Color.fromARGB(255, 81, 81, 81).withOpacity(0.5)), // Color del borde
                ),
              ),
            ),
          ),
        ),
        // Botón de enviar mensaje
        IconButton(
          icon: const Icon(Icons.send),
          color: Colors.white,
          onPressed: _sendMessage, // Llamar a la función _sendMessage cuando se presiona el botón
        ),
      ],
    );
  }
}