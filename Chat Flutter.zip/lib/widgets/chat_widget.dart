import 'package:flutter/material.dart';


class Chat extends StatelessWidget {
  final List<Map<String, dynamic>> messages = [
    {             //una lista con Mensajes que si dice "True" se van al lado derecho y si dice "False", se van al lado izquierdo.0
      'text': 'klk men',
      'sender': 'Yo',
      'imageUrl': 'https://media.istockphoto.com/id/1376008144/photo/young-people-laughing-out-loud-on-a-sunny-day-cheerful-group-of-best-friends-enjoying-summer.jpg?s=612x612&w=is&k=20&c=q01NrDToCRFORCULTzvdiu4h3bsLaVdunTtJ6UAa3y8=',
      'time': '10:30',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'imageUrl': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS-AI0ZHApwzhPtQUNCTujz-yZKxjMa2mAvGQ&s',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:33',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:34',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
    {
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },{
      'text': 'no se men',
      'sender': 'Pizza Hut',
      'time': '10:31',
      'isOwn': false,
    },
    {
      'text': 'klk men',
      'sender': 'Yo',
      'time': '10:32',
      'isOwn': true,
    },
  ];

@override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: Row(
        children: [
          // Contenedor con borde circular que muestra un icono de perfil
          Container(
            decoration: BoxDecoration(
              border: Border.all(width: 5.0),
              borderRadius: BorderRadius.all(Radius.circular(100.0)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(4.0),
              child: Image.network(
                'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRbLo9pFD4di7U3SDkQZVfCGtSLDsarN7eJNA&s',
                width: 30,
                height: 30,
                fit: BoxFit.fill,
              ),
            ),
          ),
          SizedBox(width: 8), // Espacio entre el icono y el título
          Text('Pizza Hut'), // Título de la aplicación
          Spacer(), // Espaciador para alinear los iconos a la derecha
          // Botón de llamada
          IconButton(
            onPressed: () {
              // Acción para hacer una llamada
            },
            icon: Icon(Icons.call),
            color: Colors.white,
          ),
          SizedBox(width: 8), // Espacio entre los iconos
          // Botón de videollamada
          IconButton(
            onPressed: () {
              // Acción para hacer una videollamada
            },
            icon: Icon(Icons.video_call),
            color: Colors.white,
          ),
        ],
      ),
    ),
    body: Container(
      color: Color.fromARGB(255, 249, 170, 173), // Color de fondo del cuerpo
      child: ListView.builder(
        itemCount: messages.length, // Número de mensajes a mostrar
        itemBuilder: (context, index) {
          final message = messages[index]; // Obtener el mensaje actual
          return Align(
            alignment: message['isOwn']
                ? Alignment.centerRight // Alinear mensaje propio a la derecha
                : Alignment.centerLeft, // Alinear mensaje de otro usuario a la izquierda
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
              child: Column(
                crossAxisAlignment: message['isOwn']
                    ? CrossAxisAlignment.end // Alinear el contenido del mensaje propio a la derecha
                    : CrossAxisAlignment.start, // Alinear el contenido del mensaje de otro usuario a la izquierda
                children: [
                  Text(
                    message['sender'], // Mostrar el nombre del remitente
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                  SizedBox(height: 4.0), // Espacio entre el nombre y el mensaje
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 12.0),
                    decoration: BoxDecoration(
                      color: message['isOwn']
                          ? Color.fromARGB(255, 104, 58, 70) // Color de fondo para el mensaje propio
                          : Color.fromARGB(255, 161, 82, 95), // Color de fondo para el mensaje de otro usuario
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      message['text'], // Mostrar el texto del mensaje
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  SizedBox(height: 8.0), // Espacio entre el mensaje y la imagen
                  if (message['imageUrl'] != null) // Si el mensaje tiene una imagen adjunta
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12.0), // Borde redondeado para la imagen
                        child: Image.network(
                          message['imageUrl'], // Mostrar la imagen adjunta
                          width: 300,
                          height: 200,
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  SizedBox(height: 4.0), // Espacio entre la imagen y la hora
                  Text(
                    message['time'], // Mostrar la hora del mensaje
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    ),
  );
}